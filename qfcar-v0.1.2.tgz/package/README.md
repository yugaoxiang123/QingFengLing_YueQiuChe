# 月壤车（qfcar）

一个基于 Electron 的桌面应用：主进程负责创建窗口与更新能力，渲染进程使用 Vite + React 构建页面。

## 项目架构

- **主进程（Electron Main）**：位于 [electron/main.js](file:///d:/WorkSpace/qing-feng-ling/car/electron/main.js)，负责：
  - 读取运行配置（开发/生产）
  - 创建主窗口并加载页面（本地 `index.html` 或远程 URL）
  - 单实例锁（防止重复启动）
  - 自动更新（`electron-updater`，生产环境启用）
- **渲染进程（Renderer）**：位于 [renderer](file:///d:/WorkSpace/qing-feng-ling/car/renderer)，使用 Vite 构建产物到 `renderer/dist`。
- **产物同步**：打包时将 `renderer/dist/index.html` 与 `renderer/dist/assets/` 同步到仓库根目录（供 `electron-builder` 打包），脚本见 [scripts/sync-renderer-dist.js](file:///d:/WorkSpace/qing-feng-ling/car/scripts/sync-renderer-dist.js)。
- **打包器**：使用 `electron-builder`，配置在根 [package.json](file:///d:/WorkSpace/qing-feng-ling/car/package.json) 的 `build` 字段。

## 目录结构

```
car/
  electron/                 # Electron 主进程
    main.js
  renderer/                 # 前端渲染工程（Vite + React）
    src/
    vite.config.ts
  scripts/                  # 构建辅助脚本
    electron-build.js
    sync-renderer-dist.js
  builder/                  # electron-builder 钩子等
    afterSign.js
  kylin.electron.json       # 生产/打包运行配置（会被打入安装包 resources）
  kylin.dev.electron.json   # 开发运行配置（本地开发覆盖）
```

## 组成部分与版本

- **应用版本**：根 `package.json` 的 `version`（当前：0.1.2）
- **渲染版本**：根 `package.json` 的 `render_version`（当前：0.1.2，用于内部标记）
- **主进程关键依赖**
  - Electron：18.0.2
  - electron-builder：^23.1.0
  - electron-updater：^5.0.5
- **渲染端关键依赖**
  - React：^19.1.1
  - Vite：^5.4.14

以上版本可在 [package.json](file:///d:/WorkSpace/qing-feng-ling/car/package.json) 与 [renderer/package.json](file:///d:/WorkSpace/qing-feng-ling/car/renderer/package.json) 查看。

## 运行配置（开发 / 生产）

项目通过两个 JSON 配置控制“窗口模式、入口页面、更新地址”等：

- **开发配置**：[kylin.dev.electron.json](file:///d:/WorkSpace/qing-feng-ling/car/kylin.dev.electron.json)
  - `entry`: `http://localhost:3000`（对应渲染端 dev server）
  - `window_mode`: `max`
- **生产配置**：[kylin.electron.json](file:///d:/WorkSpace/qing-feng-ling/car/kylin.electron.json)
  - `entry`: `./index.html`（打包后从 resources 加载）
  - `window_mode`: `kiosk`
  - `auto_update_url`: 自动更新地址（见下文“发布部署”）

主进程读取规则：
- **开发态**：读取仓库根目录 `kylin.electron.json`，并用 `kylin.dev.electron.json` 覆盖同名字段
- **打包态**：读取 `resources/kylin.electron.json`（`electron-builder` 的 `extraResources` 会把它带入安装包）

## 本地开发

### 环境要求

- Node.js：建议 20.19+（或 22.12+）
- Yarn：1.x

### 安装依赖

```bash
yarn install
cd renderer
yarn install
```

### 启动（渲染 + Electron）

在仓库根目录执行：

```bash
yarn dev
```

说明：
- 渲染端启动在 `http://localhost:3000`
- Electron 启动后会根据 `kylin.dev.electron.json` 加载该地址

## 打包命令与打包步骤

### 常用命令

- 构建渲染端：`yarn build:renderer`
- 同步渲染产物到根目录：`yarn sync:renderer`
- 一键构建并打包（推荐）：`yarn build`
- 生成安装包：`yarn dist`
- 只生成目录（不出安装包）：`yarn pack`

### 标准打包流程（Windows）

1. 安装依赖（根目录与 renderer）
2. 执行一键构建：
   ```bash
   yarn build
   ```
   该命令会：
   - 自动把 `version` 与 `render_version` 的 patch 位自增（例如 0.1.2 → 0.1.3）
   - 构建 `renderer`
   - 将 `renderer/dist` 同步到根目录（`index.html` + `assets/`）
   - 调用 `electron-builder` 进行打包
3. 生成物输出目录：`dist/`（由 `build.directories.output` 决定）

## 发布部署位置（自动更新与安装包发布）

### 安装包产物

打包完成后安装包位于：
- `dist/` 目录（例如 NSIS 安装包等）

### 自动更新（electron-updater）

生产配置中的自动更新地址：
- `auto_update_url`：见 [kylin.electron.json](file:///d:/WorkSpace/qing-feng-ling/car/kylin.electron.json)
- 当前值：`https://shv-software.oss-cn-zhangjiakou.aliyuncs.com/Electron-Packages/qfl-car`

部署约定（通用做法）：
- 将 `electron-builder` 生成的更新相关文件（例如 `latest.yml`、安装包文件等）上传到 `auto_update_url` 对应的目录
- 客户端在生产环境启动后会检查该地址并下载更新（配置 `auto_update_auto_restart=true` 时可下载完成后自动重启安装）

## 备注

- Electron 打包配置（目标平台、输出目录、extraResources、files 等）均在根 [package.json](file:///d:/WorkSpace/qing-feng-ling/car/package.json) 的 `build` 字段中维护。
