const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

function bumpPatch(v) {
  const parts = String(v || '0.0.0').split('.');
  const major = Number(parts[0] || 0);
  const minor = Number(parts[1] || 0);
  const patch = Number(parts[2] || 0) + 1;
  return `${major}.${minor}.${patch}`;
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + '\n', 'utf8');
}

function run(cmd, args, cwd = process.cwd()) {
  const isWin = process.platform === 'win32';
  const res = spawnSync(isWin ? `${cmd}.cmd` : cmd, args, {
    cwd,
    stdio: 'inherit',
    env: process.env
  });
  if (res.status !== 0) {
    throw new Error(`${cmd} ${args.join(' ')} 失败，退出码：${res.status}`);
  }
}

async function main() {
  const root = process.cwd();
  const pkgPath = path.join(root, 'package.json');

  console.log('正在修改版本号');
  const pkg = readJson(pkgPath);
  pkg.version = bumpPatch(pkg.version);
  pkg.render_version = bumpPatch(pkg.render_version || '0.1.0');

  const productName = process.argv[2];
  if (productName) {
    pkg.productName = productName;
    pkg.build = pkg.build || {};
    pkg.build.productName = productName;
    if (pkg.build.nsis && pkg.build.nsis.artifactName) {
      pkg.build.nsis.artifactName = `${productName} ` + '.${version}.${ext}';
    }
  }

  const name = process.argv[3];
  if (name) {
    pkg.name = name;
    if (pkg.build && pkg.build.appId) {
      const prefix = String(pkg.build.appId).match(/^.*\./);
      if (prefix && prefix[0]) {
        pkg.build.appId = `${prefix[0]}${name}`;
      }
    }
  }

  writeJson(pkgPath, pkg);
  console.log('新版本：', pkg.version);

  run('yarn', ['--cwd', 'renderer', 'build']);
  run('node', ['scripts/sync-renderer-dist.js']);

  process.argv = process.argv.slice(0, 2);
  require('electron-builder/cli');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
