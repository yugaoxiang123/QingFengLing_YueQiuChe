const { app, BrowserWindow, Menu, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { autoUpdater } = require('electron-updater');

function isOnlineLink(s) {
  return typeof s === 'string' && /^https?:\/\//i.test(s);
}

function normalizeEntryToAbsolute(entry) {
  const cleaned = String(entry || '').replace(/^\.\//, '');
  if (!cleaned) return '';
  if (path.isAbsolute(cleaned)) return cleaned;
  return path.join(app.getAppPath(), cleaned);
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function getConfigPaths() {
  const root = process.cwd();
  if (app.isPackaged) {
    return {
      prod: path.join(process.resourcesPath, 'kylin.electron.json'),
      dev: null
    };
  }
  return {
    prod: path.join(root, 'kylin.electron.json'),
    dev: path.join(root, 'kylin.dev.electron.json')
  };
}

function loadConfig() {
  const defaults = {
    window_mode: undefined,
    entry: '',
    window: {
      width: 1280,
      height: 720,
      show: true,
      autoHideMenuBar: true,
      backgroundColor: '#000000',
      webPreferences: {
        contextIsolation: true,
        nodeIntegration: false
      }
    },
    auto_update_url: '',
    auto_update_time: 0,
    auto_update_auto_restart: false
  };

  const { prod, dev } = getConfigPaths();
  const prodConfig = readJson(prod) || {};
  const devConfig = dev ? readJson(dev) || {} : {};

  return {
    ...defaults,
    ...prodConfig,
    ...devConfig,
    window: {
      ...defaults.window,
      ...(prodConfig.window || {}),
      ...(devConfig.window || {}),
      webPreferences: {
        ...(defaults.window.webPreferences || {}),
        ...((prodConfig.window && prodConfig.window.webPreferences) || {}),
        ...((devConfig.window && devConfig.window.webPreferences) || {})
      }
    }
  };
}

function applyWindowMode(win, mode) {
  if (mode === 'kiosk') {
    win.setKiosk(true);
    win.setResizable(false);
    return;
  }
  if (mode === 'full') {
    win.setFullScreen(true);
    win.setResizable(false);
    return;
  }
  if (mode === 'max') {
    win.maximize();
  }
}

function setupAutoUpdate(config) {
  if (!app.isPackaged) return;
  if (!config.auto_update_url) return;

  autoUpdater.requestHeaders = {
    'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0'
  };
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;

  autoUpdater.on('error', (e) => {
    console.error('[autoUpdater] error', e);
  });

  autoUpdater.on('update-available', (info) => {
    console.log('[autoUpdater] update-available', info && info.version);
  });

  autoUpdater.on('update-not-available', () => {
    console.log('[autoUpdater] update-not-available');
  });

  autoUpdater.on('download-progress', (p) => {
    const win = BrowserWindow.getAllWindows()[0];
    if (!win) return;
    const percent = Math.max(0, Math.min(100, Math.floor(Number(p.percent || 0))));
    win.setProgressBar(percent / 100);
  });

  autoUpdater.on('update-downloaded', async () => {
    if (config.auto_update_auto_restart) {
      autoUpdater.quitAndInstall(true, true);
    }
  });

  autoUpdater.setFeedURL(config.auto_update_url);
  autoUpdater.checkForUpdates();

  const t = Number(config.auto_update_time || 0);
  if (t > 0) {
    setInterval(() => autoUpdater.checkForUpdates(), t);
  }
}

function createMainWindow(config) {
  const win = new BrowserWindow(config.window);
  Menu.setApplicationMenu(null);

  if (isOnlineLink(config.entry)) {
    win.loadURL(config.entry);
  } else {
    const filePath = normalizeEntryToAbsolute(config.entry);
    if (!filePath) {
      throw new Error('未配置 entry');
    }
    win.loadFile(filePath);
  }

  win.once('ready-to-show', () => {
    applyWindowMode(win, config.window_mode);
  });

  return win;
}

async function main() {
  try {
    app.commandLine.appendSwitch('disable-http2');
    app.commandLine.appendSwitch('--disable-http-cache');
    app.commandLine.appendSwitch('--disable-gpu-process-crash-limit');
    app.disableDomainBlockingFor3DAPIs();

    const gotLock = app.requestSingleInstanceLock();
    if (!gotLock) {
      app.exit(0);
      return;
    }

    const config = loadConfig();

    app.on('second-instance', () => {
      const win = BrowserWindow.getAllWindows()[0];
      if (!win) return;
      if (win.isMinimized()) win.restore();
      win.show();
      win.focus();
    });

    await app.whenReady();

    createMainWindow(config);
    setupAutoUpdate(config);

    app.on('window-all-closed', () => {
      if (process.platform !== 'darwin') app.quit();
    });

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow(config);
      }
    });
  } catch (e) {
    console.error(e);
    try {
      dialog.showErrorBox('温馨提示', e && e.message ? e.message : String(e));
    } catch {}
    if (app.isReady()) app.quit();
    else app.exit(1);
  }
}

main();
